/*
 * monitor.js — Milestone 2 frontend agent.
 *
 * 1. Captures webcam frames every FRAME_INTERVAL_MS and POSTs them to the
 *    face-presence endpoint for OpenCV Haar Cascade detection.
 * 2. Listens for browser-level integrity signals (tab switch / focus loss,
 *    fullscreen exit, copy/paste, right-click, devtools) and POSTs each as
 *    an activity_event.
 */

const SESSION_ID = window.EXAMGUARD_SESSION_ID;
const FRAME_INTERVAL_MS = 3000;

const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const faceStatus = document.getElementById('faceStatus');
const eventCountEl = document.getElementById('eventCount');
const eventLogEl = document.getElementById('eventLog');

let loggedEventCount = 0;

function appendLogLine(text) {
  loggedEventCount += 1;
  eventCountEl.textContent = loggedEventCount;
  const li = document.createElement('li');
  li.textContent = `${new Date().toLocaleTimeString()} — ${text}`;
  eventLogEl.prepend(li);
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return res.json();
}

function logEvent(eventType, meta) {
  postJSON(`/api/session/${SESSION_ID}/event`, { event_type: eventType, meta: meta || null })
    .then(data => {
      appendLogLine(eventType.replace(/_/g, ' '));
      if (data.flags && data.flags.length) {
        appendLogLine(`⚠ rule engine: ${data.flags.map(f => f.rule_code).join(', ')}`);
      }
    })
    .catch(() => {});
}

// ---- webcam face-presence loop ------------------------------------------

navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    video.srcObject = stream;
    setInterval(captureAndSendFrame, FRAME_INTERVAL_MS);
  })
  .catch(() => {
    faceStatus.textContent = 'camera unavailable';
  });

function captureAndSendFrame() {
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.7);

  postJSON(`/api/session/${SESSION_ID}/frame`, { frame: dataUrl })
    .then(data => {
      if (data.error) return;
      faceStatus.textContent = data.face_present
        ? `face present (${data.face_count})`
        : 'face NOT detected';
      faceStatus.className = data.face_present ? 'ok' : 'warn';
    })
    .catch(() => {});
}

// ---- browser integrity events --------------------------------------------

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    logEvent('tab_switch');
  } else {
    logEvent('focus_regain');
  }
});

window.addEventListener('blur', () => logEvent('focus_loss'));
window.addEventListener('focus', () => logEvent('focus_regain'));

document.addEventListener('fullscreenchange', () => {
  if (!document.fullscreenElement) logEvent('fullscreen_exit');
});

document.addEventListener('copy', () => logEvent('copy'));
document.addEventListener('paste', () => logEvent('paste'));
document.addEventListener('contextmenu', () => logEvent('right_click'));

// crude devtools-open heuristic (window size delta) — good enough for Milestone 2 scope
let devtoolsWarned = false;
setInterval(() => {
  const threshold = 160;
  const widthDelta = window.outerWidth - window.innerWidth;
  const heightDelta = window.outerHeight - window.innerHeight;
  if ((widthDelta > threshold || heightDelta > threshold) && !devtoolsWarned) {
    devtoolsWarned = true;
    logEvent('devtools_open');
  }
}, 2000);

// ---- session controls ------------------------------------------------------

document.getElementById('pauseBtn').addEventListener('click', () => {
  postJSON(`/api/session/${SESSION_ID}/pause`, {}).then(() => location.reload());
});
document.getElementById('resumeBtn').addEventListener('click', () => {
  postJSON(`/api/session/${SESSION_ID}/resume`, {}).then(() => location.reload());
});
document.getElementById('submitBtn').addEventListener('click', () => {
  postJSON(`/api/session/${SESSION_ID}/submit`, {}).then(data => {
    alert('Exam submitted. Flags: ' + (data.flags || []).map(f => f.rule_code).join(', ') || 'none');
    window.location.href = '/dashboard';
  });
});
